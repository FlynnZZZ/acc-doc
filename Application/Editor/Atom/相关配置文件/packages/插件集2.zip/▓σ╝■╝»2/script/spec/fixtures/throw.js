throw new Error('kaboom');
