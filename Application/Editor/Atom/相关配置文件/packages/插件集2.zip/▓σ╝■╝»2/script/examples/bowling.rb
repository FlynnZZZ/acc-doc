# From http://rspec.info

class Bowling
  def hit(pins)
  end

  def score
    0
  end
end
