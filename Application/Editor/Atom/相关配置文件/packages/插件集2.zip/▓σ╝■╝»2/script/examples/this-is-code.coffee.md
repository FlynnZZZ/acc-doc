These are just words.

      console.log 'This is code!'
