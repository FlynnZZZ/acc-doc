# 微信小程序语法高亮(atom-wx)

- 支持 wxml 文件语法高亮
- 支持 wxss 文件语法高亮


### 安装
- run `apm install vim-mode`

### 来源
- 代码来源于官方的 language-xml 和 language-css
