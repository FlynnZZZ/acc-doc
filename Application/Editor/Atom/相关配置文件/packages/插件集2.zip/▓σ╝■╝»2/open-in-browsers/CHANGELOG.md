todo

* hyper live -browser-plus live/refresh issues..?
* rewrite  pp - reduce the no of function - cleaner implementation- live preview ???
* sync scroll
* more plugins/zoom in plugin
* at project level -> ui for localhost->
* make scroll sync for browser-plus

##0.4.0 - Fourth Release (Current)
changed linux setting for opening chrome to google-chrome (https://github.com/skandasoft/open-in-browsers/issues/7)
checking if it is a real editor before opening file(https://github.com/skandasoft/open-in-browsers/issues/11)
fix the MS Edge issue - added colon as per the thread
(https://github.com/skandasoft/open-in-browsers/issues/3)

## 0.3.0 - Third Release
* config for maintaining the fileTypes for open-in-browsers
* ContextMenu as per the config #6
* added icon from font-awesome for all the browsers #5
* added edge browser to the list of windows browser..did not get a chance to test #3
* fixed notifications.addSuccess #4
* fixed default browser menu open-in-browsers:toggle #2
* made PP Compliant(https://github.com/skandasoft/pp ~ https://atom.io/packages/pp : Preview-Plus - will be releasing soon)  (<pp-options> works!!!)
* added localhost setting - (in next release ~with ability to maintain at the project level if project manager package is available )


## 0.2.0 - Second Release
* Added Config setting to select display of browsers to be shown in status bar
* Context Menu for html and htm files with all browsers

## 0.1.0 - First Release
* Every feature added
* Every bug fixed
