<?php
  $test = "$test";
  // Some $test @test file
  // Don't highlight thistest, or testthis
?>
