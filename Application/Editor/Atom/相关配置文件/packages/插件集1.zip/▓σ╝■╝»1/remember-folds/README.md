# remember-folds package

Remembers and automatically re-folds folds in your text editors

![A screenshot of your package](http://i.imgur.com/WZCBjsZ.gif)
