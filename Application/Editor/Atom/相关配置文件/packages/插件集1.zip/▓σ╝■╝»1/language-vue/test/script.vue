<!--
  Support language-todo correctly
  https://github.com/hedefalk/atom-vue/issues/52
-->

<script>
// NOTE: this 'NOTE' should be highlighted
// NOTE: this 'NOTE' should be highlighted too </script>
