Syntax highlighting for single-file [Vue.js](http://vuejs.org) components supports in [Atom](https://atom.io/) (enabled by [Vueify](https://github.com/vuejs/vueify) or [vue-loader](https://github.com/vuejs/vue-loader)).

*This syntax highlighting is translated from [Vue.js author's Sublime Text syntax highlighting for single-file Vue components](https://github.com/vuejs/vue-syntax-highlight).*

**NOTE:** You still need to install corresponding packages for pre-processors (e.g. Jade, SASS, CoffeeScript) to get proper syntax highlighting for them.
