/(foo|bar)/
const DEFAULT_PATTERN = /([a-zA-Z]{2,5})-?(\d{3,5})/g;

var a = /^foo/

			.replace(/(\+\d+)? ?(\d{2}) ?(\d{2}) ?(\d{2}) ?(\d{2})/g, '$1 $2 $3 $4 $5')
			.replace(/(\+\d+)? ?(\d{2}) ?(\d{2}) ?(\d{2}) ?(\d{2})/g, '$1 $2 $3 $4 $5')
			/./

foo|bar
/dbo\.Test\(\)/

/^\/((deu|fra|nel)\/(de|en|fr|nl))\//i
