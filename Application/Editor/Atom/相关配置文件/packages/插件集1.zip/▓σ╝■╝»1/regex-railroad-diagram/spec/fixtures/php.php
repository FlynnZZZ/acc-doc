<?php
   php_regex_replace("/foo/", "")
   if (! preg_match('/^[RK]_.{16}\.pdf$/', $name)) {
?>
